from . import base
from .things import Drop
from ..enums import ActionName, Property


class Attack(base.Action):
    ACTION_NAME = ActionName.ATTACK
    ACTION_DESCRIPTION = "Attack someone with a weapon"
    ACTION_ALIASES = ["hit"]

    def __init__(self, game, command: str, actor=None):
        super().__init__(game, actor=actor)
        attack_words = ["attack", "hit"]
        self.attacker = self.acting_character(
            command, hint="attacker", split_words=attack_words, position="before"
        )
        self.victim = self.target_character(
            command,
            hint="victim",
            split_words=attack_words,
            position="after",
            exclude=self.attacker,
        )
        # A weapon serves from the hand as well as the pack: wielding moves
        # an item OUT of inventory (Character.wield), so matching against
        # inventory alone made "wield blade; attack troll with blade" claim
        # the attacker was unarmed.
        held = {
            **self.attacker.inventory,
            **getattr(self.attacker, "wielded", {}),
        }
        self.weapon = self.parser.match_item(command, held, hint="weapon")

    def check_preconditions(self) -> bool:
        """
        Preconditions:
        * There must be an attacker and a victim
        * They must be in the same location
        * There must be a matched weapon
        * The attacker must have the weapon in their inventory
        * The weapon have the property 'is_weapon'
        * The victim must not already be dead or unconscious
        """
        if not self.was_matched(self.attacker):
            description = "The attacker couldn't be found."
            self.parser.fail(description)
            return False
        if not self.was_matched(self.victim):
            description = "The character to attack wasn't matched."
            self.parser.fail(description)
            return False
        if not self.attacker.location.here(self.victim):
            description = "The two characters must be in the same location."
            self.parser.fail(description)
            return False
        if not self.was_matched(
            self.weapon,
            error_message="{name} {verb} have a weapon.".format(
                name=self.attacker.name.capitalize(),
                verb=base.conjugate(self.attacker, "don't", "doesn't"),
            ),
        ):
            return False
        if not (
            self.attacker.is_in_inventory(self.weapon)
            or self.attacker.is_wielded(self.weapon)
        ):
            description = "{name} {verb} have the {weapon}.".format(
                name=self.attacker.name.capitalize(),
                verb=base.conjugate(self.attacker, "don't", "doesn't"),
                weapon=self.weapon.name,
            )
            self.parser.fail(description)
            return False
        if not self.weapon.get_property(Property.IS_WEAPON):
            description = "{item} is not a weapon".format(item=self.weapon.name)
            self.parser.fail(description)
            return False
        if self.victim.get_property(Property.IS_UNCONSCIOUS):
            description = "{name} {verb} already unconscious".format(
                name=self.victim.name.capitalize(),
                verb=base.conjugate(self.victim, "are", "is"),
            )
            self.parser.fail(description)
            return False
        if self.victim.get_property(Property.IS_DEAD):
            description = "{name} {verb} already dead".format(
                name=self.victim.name.capitalize(),
                verb=base.conjugate(self.victim, "are", "is"),
            )
            self.parser.fail(description)
            return False
        return True

    def apply_effects(self):
        """
        Effects:
        * If the victim is not invulerable to attacks
        ** Knocks the victim unconscious
        ** The victim drops all items in their inventory
        * If the weapon is fragile then it breaks
        """
        description = "{attacker} attacked {victim} with the {weapon}.".format(
            attacker=self.attacker.name,
            victim=self.victim.name,
            weapon=self.weapon.name,
        )
        self.parser.ok(description)

        if self.weapon.get_property(Property.IS_FRAGILE):
            description = "The fragile weapon broke into pieces."
            if self.attacker.is_wielded(self.weapon):
                self.attacker.wielded.pop(self.weapon.name)
                self.weapon.set_owner(None)
            else:
                self.attacker.remove_from_inventory(self.weapon)
            self.parser.ok(description)

        if self.victim.get_property(Property.IS_INVULNERABLE):
            description = "The attack has no effect on {name}.".format(
                name=self.victim.name
            )
            self.parser.ok(description)
        else:
            # VIGOR (Vaarn): how many blows the fiction lets a character
            # take. Unset (or 1) is the classic one-hit knockout, so every
            # existing game and NPC is untouched. A tougher character -- a
            # pack, a synth, a boss -- sets vigor N: each hit costs one, and
            # only the last blow fells them. A non-final hit narrates via the
            # victim's struck_text (or a plain default) and ends there.
            vigor = self.victim.get_property("vigor")
            if vigor is not None and int(vigor) > 1:
                self.victim.set_property("vigor", int(vigor) - 1)
                struck = self.victim.get_property("struck_text") or (
                    "The blow lands, and {name} {verb} standing.".format(
                        name=self.victim.name,
                        verb=base.conjugate(self.victim, "stay", "stays"),
                    )
                )
                self.parser.ok(struck)
                return
            if vigor is not None:
                self.victim.set_property("vigor", 0)
            # the victim is knocked unconscious
            self.victim.set_property(Property.IS_UNCONSCIOUS, True)
            # A victim may supply its own knockout line (a boss that shrugs
            # off the blow reads wrong as "knocked unconscious").
            description = self.victim.get_property("ko_text") or (
                "{name} {verb} knocked unconscious.".format(
                    name=self.victim.name.capitalize(),
                    verb=base.conjugate(self.victim, "were", "was"),
                )
            )
            self.parser.ok(description)

            # the victim drops their inventory
            items = list(self.victim.inventory.keys())
            for item_name in items:
                item = self.victim.inventory[item_name]
                command = "{victim} drop {item}".format(
                    victim=self.victim.name, item=item_name
                )
                drop = Drop(self.game, command)
                if drop.check_preconditions():
                    drop.apply_effects()
